from django.shortcuts import render, redirect
from . import models
from . import utils


# Create your views here.
def index(request):
    if request.method == 'GET':
        return render(request, 'index.html')


def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        query = models.User.objects.filter(email=email)
        if len(query) == 0:
            query = models.User.objects.filter(username=username)
            if len(query) == 0:
                query = models.User.objects.create(email=email, username=username, password=password)
                query.save()
                return redirect(f'/login/?username={username}')
            return redirect('/error/?code=2')
        return redirect('/error/?code=1')
    return render(request, 'signup.html')


def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        query = models.User.objects.filter(email=email, password=password)
        if len(query) == 0:
            return redirect('/error/?code=3')
        query = models.User.objects.get(email=email)
        query.active = True
        query.save()
        username = query.username
        return redirect(f'/home/{username}')
    return render(request, 'login.html')


def error(request):
    code = request.GET.get('code')
    if request.method == 'GET':
        if code == '1':
            message = 'USER ALREADY EXISTS. LOGIN INSTEAD.'
            return render(request, 'error.html', context={'message': message})
        if code == '2':
            message = 'USERNAME ALREADY EXISTS. CREATE A UNIQUE USERNAME.'
            return render(request, 'error.html', context={'message': message})
        if code == '3':
            message = 'USER DOES NOT EXIST. SIGNUP INSTEAD.'
            return render(request, 'error.html', context={'message': message})
        if code == '4':
            message = 'NO SUCH AUTHOR.'
            return render(request, 'error.html', context={'message': message})
        if code == 5:
            message = 'NO SUCH BLOG.'
            return render(request, 'error.html', context={'message': message})


def home(request, username):
    if request.method == 'POST':
        query = models.User.objects.get(username=username)
        if query.active:
            query.active = False
            query.save()
            return redirect(f'/?username={username}')
        return redirect(f'/login/?username={username}')
    query = models.User.objects.filter(username=username, active=True)
    if len(query) == 0:
        return redirect(f'/login/?username={username}')
    query = models.User.objects.get(username=username)
    email = query.email
    blogs = models.Blog.objects.filter(email=email)
    return render(request, 'home.html', context={'username': username, 'blogs': blogs})


def new(request, username):
    if request.method == 'POST':
        title = request.POST['title']
        content = request.POST['content']
        query = models.User.objects.get(username=username)
        if query.active:
            query = models.Blog.objects.filter(title=title)
            if len(query) == 0:
                query = models.User.objects.get(username=username)
                blog_id = utils.generate_random_and_unique_id()
                query = models.Blog.objects.create(blog_id=blog_id, title=title, content=content, email=query)
                query.save()
                return redirect(f'/home/{username}')
            query = models.Blog.objects.get(title=title)
            blog_id = query.blog_id
            return redirect(f'/edit/?blog_id={blog_id}')
        return redirect(f'/login/?username={username}')
    query = models.User.objects.filter(username=username, active=True)
    if len(query) == 0:
        return redirect(f'/login/?username={username}')
    return render(request, 'new.html', context={'username': username})


def edit(request, username):
    blog_id = request.GET.get('blog_id')
    if request.method == 'POST':
        title = request.POST['title']
        content = request.POST['content']
        query = models.User.objects.get(username=username)
        if query.active:
            query = models.Blog.objects.filter(title=title)
            if len(query) == 0:
                query = models.Blog.objects.get(blog_id=blog_id)
                query.title = title
                query.content = content
                query.save()
                return redirect(f'/home/{username}')
            return redirect(f'/home/{username}/edit/?blog_id={blog_id}')
        return redirect(f'/login/?username={username}')
    query = models.User.objects.filter(username=username, active=True)
    if len(query) == 0:
        return redirect(f'/login/?username={username}')
    query = models.Blog.objects.get(blog_id=blog_id)
    title = query.title
    content = query.content
    return render(request, 'edit.html', context={'username': username, 'title': title, 'content': content})


def delete(request, username):
    blog_id = request.GET.get('blog_id')
    if request.method == 'POST':
        query = models.User.objects.get(username=username)
        if query.active:
            query = models.Blog.objects.get(blog_id=blog_id)
            query.delete()
            return redirect(f'/home/{username}')
        return redirect(f'/login/?username={username}')
    query = models.User.objects.filter(username=username, active=True)
    if len(query) == 0:
        return redirect(f'/login/?username={username}')
    return render(request, 'delete.html', context={'username': username})


def author(request, username):
    if request.method == 'GET':
        query = models.User.objects.filter(username=username)
        if len(query) == 0:
            return redirect('error/?code=4')
        query = models.User.objects.get(username=username)
        email = query.email
        blogs = models.Blog.objects.filter(email=email)
        return render(request, 'author.html', context={'username': username, 'blogs': blogs})


def blog(request, username, blog_id):
    if request.method == 'GET':
        query = models.User.objects.filter(username=username)
        if len(query) == 0:
            return redirect('/error/?code=5')
        query = models.User.objects.get(username=username)
        email = query.email
        query = models.Blog.objects.filter(email=email, blog_id=blog_id)
        if len(query) == 0:
            return redirect('/error/?code=5')
        query = models.Blog.objects.get(blog_id=blog_id)
        title = query.title
        content = query.content
        return render(request, 'article.html', context={'title': title, 'content': content})
