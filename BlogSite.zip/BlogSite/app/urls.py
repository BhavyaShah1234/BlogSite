from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('error/', views.error, name='error'),
    path('home/<str:username>/', views.home, name='home'),
    path('home/<str:username>/new/', views.new, name='new'),
    path('home/<str:username>/edit/', views.edit, name='edit'),
    path('home/<str:username>/delete/', views.delete, name='delete'),
    path('read/<str:username>/', views.author, name='author'),
    path('read/<str:username>/<str:blog_id>/', views.blog, name='article'),
]
