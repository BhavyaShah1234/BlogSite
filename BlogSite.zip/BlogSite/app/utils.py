from . import models
from django.utils.crypto import get_random_string
import string


def generate_random_and_unique_id():
    blog_id = get_random_string(10, string.ascii_lowercase + string.ascii_uppercase + string.digits)
    query = models.Blog.objects.filter(blog_id=blog_id)
    if len(query) == 0:
        return blog_id
    generate_random_and_unique_id()
